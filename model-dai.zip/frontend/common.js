// Minimal helper for API requests
    const API_BASE = localStorage.getItem('API_BASE') || 'http://localhost:4000';
    function setApiBase(url){ localStorage.setItem('API_BASE', url); }
    async function api(path, opts={}){
      const token = localStorage.getItem('token');
      const headers = Object.assign({'Content-Type':'application/json'}, opts.headers||{});
      if(token) headers['Authorization'] = 'Bearer ' + token;
      const res = await fetch(API_BASE + path, Object.assign({}, opts, {headers}));
      if(!res.ok){ const t = await res.text(); throw new Error(t || ('HTTP '+res.status)); }
      const ct = res.headers.get('content-type')||'';
      return ct.includes('application/json') ? res.json() : res.text();
    }
    function byId(id){ return document.getElementById(id); }
    function go(href){ location.href = href; }
