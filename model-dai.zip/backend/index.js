import express from 'express';
    import cors from 'cors';
    import fs from 'fs';
    import path from 'path';
    import { fileURLToPath } from 'url';
    import jwt from 'jsonwebtoken';
    import bcrypt from 'bcryptjs';
    import { v4 as uuidv4 } from 'uuid';
    import QRCode from 'qrcode';
    import dotenv from 'dotenv';
    import { ethers } from 'ethers';

    dotenv.config();
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = path.dirname(__filename);
    const app = express();
    const PORT = process.env.PORT || 4000;
    const DB_PATH = path.join(__dirname, 'db.json');

    app.use(cors());
    app.use(express.json({limit:'10mb'}));

    function readDB(){
      return JSON.parse(fs.readFileSync(DB_PATH,'utf-8'));
    }
    function writeDB(data){
      fs.writeFileSync(DB_PATH, JSON.stringify(data,null,2));
    }

    // Auth helpers
    function sign(user){ return jwt.sign({id:user.id,email:user.email,role:user.role||'user'}, process.env.JWT_SECRET, {expiresIn:'7d'}); }
    function auth(req,res,next){
      const h = req.headers.authorization||'';
      const t = h.startsWith('Bearer ')?h.slice(7):null;
      if(!t) return res.status(401).send('No token');
      try{ req.user = jwt.verify(t, process.env.JWT_SECRET); next(); }
      catch(e){ return res.status(401).send('Invalid token'); }
    }
    function admin(req,res,next){
      if(req.user?.role === 'admin') return next();
      return res.status(403).send('Admin only');
    }

    // Web3 (optional for demo; will be active when env is set)
    const provider = process.env.WEB3_PROVIDER_URL ? new ethers.JsonRpcProvider(process.env.WEB3_PROVIDER_URL) : null;
    const contractAddress = process.env.CONTRACT_ADDRESS || null;
    const abi = [
      "function registerCertificate(string cid,string holder,string title,string issuer,string hash) public returns (uint256)",
      "function getCertificate(string cid) public view returns (tuple(string holder,string title,string issuer,string hash,uint256 blockNumber,bool exists))"
    ];
    let contract = null;
    if(provider && contractAddress){ contract = new ethers.Contract(contractAddress, abi, provider); }

    // Routes
    app.get('/', (req,res)=> res.json({ ok:true, message:'API running' }));

    app.post('/api/auth/register', (req,res)=>{
      const {name,email,password} = req.body;
      if(!name||!email||!password) return res.status(400).send('Missing fields');
      const db = readDB();
      if(db.users.find(u=>u.email===email)) return res.status(400).send('Email exists');
      const user = { id: uuidv4(), name, email, password: bcrypt.hashSync(password,10), role:'user' };
      db.users.push(user); writeDB(db);
      res.json({ id:user.id, name, email });
    });

    app.post('/api/auth/login', (req,res)=>{
      const {email,password} = req.body;
      const db = readDB();
      const user = db.users.find(u=>u.email===email);
      if(!user || !bcrypt.compareSync(password, user.password)) return res.status(401).send('Invalid credentials');
      const token = sign(user);
      res.json({ token });
    });

    // Create certificate
    app.post('/api/certificates', auth, async (req,res)=>{
      const { title, issuer, holder, issueDate, fileB64 } = req.body;
      if(!title||!issuer||!holder) return res.status(400).send('Missing fields');
      const db = readDB();
      const id = 'CERT-' + uuidv4();
      const cert = { id, title, issuer, holder, issueDate: issueDate||null, ownerId:req.user.id, createdAt:Date.now(), fileB64:fileB64||null };
      db.certificates.push(cert); writeDB(db);
      const qr = await QRCode.toDataURL(id);
      res.json({ ...cert, qr });
    });

    // List certificates (admin or owner)
    app.get('/api/certificates', auth, (req,res)=>{
      const db = readDB();
      const list = req.user.role==='admin' ? db.certificates : db.certificates.filter(c=>c.ownerId===req.user.id);
      res.json(list);
    });

    // Verify by ID
    app.get('/api/verify/:cid', async (req,res)=>{
      const db = readDB();
      const cert = db.certificates.find(c=>c.id===req.params.cid);
      const out = { exists: !!cert, source:'db', cert: cert||null };
      // Optionally check chain
      if(contract){
        try{
          const onchain = await contract.getCertificate(req.params.cid);
          out.onchain = onchain;
        }catch(e){ out.onchainError = e.message; }
      }
      res.json(out);
    });

    // Blockchain register (requires server wallet private key via WEB3_PRIVATE_KEY if needed)
    app.post('/api/blockchain/register/:cid', auth, async (req,res)=>{
      const cid = req.params.cid;
      const db = readDB(); const cert = db.certificates.find(c=>c.id===cid);
      if(!cert) return res.status(404).send('Not found');
      if(!process.env.WEB3_PROVIDER_URL || !process.env.CONTRACT_ADDRESS) return res.status(400).send('Web3 not configured');
      const pk = process.env.WEB3_PRIVATE_KEY;
      if(!pk) return res.status(400).send('Missing WEB3_PRIVATE_KEY');
      try{
        const wallet = new ethers.Wallet(pk, provider);
        const contractWrite = new ethers.Contract(process.env.CONTRACT_ADDRESS, abi, wallet);
        const tx = await contractWrite.registerCertificate(cid, cert.holder, cert.title, cert.issuer, ethers.keccak256(ethers.toUtf8Bytes(JSON.stringify(cert))));
        const receipt = await tx.wait();
        res.json({ ok:true, txHash: receipt.hash });
      }catch(e){ res.status(500).send(e.message); }
    });

    // Mock payment
    app.post('/api/payment/mock', auth, (req,res)=>{
      const {amount} = req.body;
      res.json({ status:'paid', amount: Number(amount||0), reference: uuidv4() });
    });

    app.listen(PORT, ()=> console.log('API on http://localhost:'+PORT));
