# Dai – Certificate Verification Platform

    ## Structure
    - `frontend/` Pure HTML, CSS, JS – open `index.html` directly (no build needed).
    - `backend/` Node + Express API – `npm i && npm run start`.
    - `smart-contract/` Solidity file for Remix.

    ## Backend setup
    ```bash
    cd backend
    cp .env.example .env
    npm install
    npm start
    ```

    ## Frontend
    Open `frontend/index.html` in your browser. Set **API Base URL** to your backend (e.g., http://localhost:4000).

    ## Smart Contract (Remix)
    - Open Remix, create a new file `CertificateRegistry.sol`, paste contents from `smart-contract/CertificateRegistry.sol`.
    - Compile with Solidity ^0.8.20
    - Deploy, copy the deployed **CONTRACT_ADDRESS** to backend `.env`.

    ## Required Pages (per wireframes)
    - Welcome (index.html)
    - SignUp (signup.html)
    - SignIn (signin.html)
    - Home (home.html) with: Upload (upload.html), Verify (verify.html), Payment (payment.html), Admin (admin.html)

    ## Notes
    - DB is a simple JSON file `db.json` for easy running in demos.
    - `/api/blockchain/register/:cid` writes a certificate to the chain (when Web3 env values are set).
